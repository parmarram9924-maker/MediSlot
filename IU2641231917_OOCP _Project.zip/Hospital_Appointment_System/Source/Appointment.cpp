#include "Appointment.h"
#include <iostream>
Appointment::Appointment():id(0),patientId(0),doctorId(0),date(""),time(""),status("Booked"){}
Appointment::Appointment(int i,int p,int d,const std::string& da,const std::string& ti,const std::string& st):id(i),patientId(p),doctorId(d),date(da),time(ti),status(st){}
int Appointment::getId()const{return id;} int Appointment::getPatientId()const{return patientId;} int Appointment::getDoctorId()const{return doctorId;}
std::string Appointment::getDate()const{return date;} std::string Appointment::getTime()const{return time;} std::string Appointment::getStatus()const{return status;}
void Appointment::setDateTime(const std::string& d,const std::string& t){date=d;time=t;}
void Appointment::setStatus(const std::string& s){status=s;}
void Appointment::display()const{std::cout<<"Appointment #"<<id<<" | Patient ID: "<<patientId<<" | Doctor ID: "<<doctorId<<" | "<<date<<" "<<time<<" | "<<status;}
