#ifndef PATIENT_H
#define PATIENT_H
#include "Person.h"
class Patient : public Person {
    int age;
    std::string gender;
public:
    Patient();
    Patient(int id,const std::string& name,const std::string& phone,int age,const std::string& gender);
    std::string role() const override;
    void display() const override;
    int getAge() const;
    std::string getGender() const;
};
#endif
