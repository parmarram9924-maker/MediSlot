#include <iostream>
#include <limits>
#include "Hospital.h"
int main(){
    Hospital system;
    int choice=0;
    do{
        std::cout<<"\n========================================\n";
        std::cout<<"       HOSPITAL APPOINTMENT SYSTEM\n";
        std::cout<<"========================================\n";
        std::cout<<"1. Add Record\n2. Display Records\n3. Search Record\n4. Update Record\n5. Delete Record\n6. Main Transaction / Book Appointment\n7. Report\n8. Save / Load Information\n9. Exit\n";
        std::cout<<"Enter choice: ";
        if(!(std::cin>>choice)){std::cout<<"Invalid input. Please enter a number.\n";std::cin.clear();std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');continue;}
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
        try{
            switch(choice){case 1:system.addRecord();break;case 2:system.displayRecords();break;case 3:system.searchRecord();break;case 4:system.updateRecord();break;case 5:system.deleteRecord();break;case 6:system.bookAppointment();break;case 7:system.report();break;case 8:system.saveLoadMenu();break;case 9:std::cout<<"Saving data and exiting. Goodbye!\n";break;default:std::cout<<"Choose a number from 1 to 9.\n";}
        }catch(const std::exception&e){std::cout<<"Operation failed: "<<e.what()<<'\n';}
    }while(choice!=9);
    return 0;
}
