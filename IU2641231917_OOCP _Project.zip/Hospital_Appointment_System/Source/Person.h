#ifndef PERSON_H
#define PERSON_H
#include <string>
class Person {
protected:
    int id;
    std::string name, phone;
public:
    Person();
    Person(int id, const std::string& name, const std::string& phone);
    virtual ~Person();
    int getId() const;
    std::string getName() const;
    std::string getPhone() const;
    virtual std::string role() const;
    virtual void display() const;
};
#endif
