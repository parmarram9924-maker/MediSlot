#ifndef HOSPITAL_H
#define HOSPITAL_H
#include <vector>
#include "Patient.h"
#include "Doctor.h"
#include "Appointment.h"
#include "FileManager.h"
class Hospital {
    std::vector<Patient> patients;
    std::vector<Doctor> doctors;
    std::vector<Appointment> appointments;
    FileManager files;
    int nextPatientId,nextDoctorId,nextAppointmentId;
    void saveAll() const;
public:
    Hospital();
    ~Hospital();
    void loadAll();
    void addRecord();
    void displayRecords() const;
    void searchRecord() const;
    void updateRecord();
    void deleteRecord();
    void bookAppointment();
    void report() const;
    void saveLoadMenu();
};
#endif
