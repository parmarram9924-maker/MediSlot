#ifndef APPOINTMENT_H
#define APPOINTMENT_H
#include <string>
class Appointment {
    int id, patientId, doctorId;
    std::string date, time, status;
public:
    Appointment();
    Appointment(int id,int patientId,int doctorId,const std::string& date,const std::string& time,const std::string& status="Booked");
    int getId() const;
    int getPatientId() const;
    int getDoctorId() const;
    std::string getDate() const;
    std::string getTime() const;
    std::string getStatus() const;
    void setDateTime(const std::string& date,const std::string& time);
    void setStatus(const std::string& status);
    void display() const;
};
#endif
