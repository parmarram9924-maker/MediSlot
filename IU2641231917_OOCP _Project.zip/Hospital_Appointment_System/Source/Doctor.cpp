#include "Doctor.h"
#include <iostream>
Doctor::Doctor():Person(),specialization(""){}
Doctor::Doctor(int i,const std::string& n,const std::string& p,const std::string& s):Person(i,n,p),specialization(s){}
std::string Doctor::role() const{return "Doctor";}
void Doctor::display() const {Person::display();std::cout<<" | Specialization: "<<specialization;}
std::string Doctor::getSpecialization() const{return specialization;}
