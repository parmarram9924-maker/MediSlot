#include "Person.h"
#include <iostream>
Person::Person() : id(0), name(""), phone("") {}
Person::Person(int i,const std::string& n,const std::string& p):id(i),name(n),phone(p){}
Person::~Person() {}
int Person::getId() const{return id;}
std::string Person::getName() const{return name;}
std::string Person::getPhone() const{return phone;}
std::string Person::role() const{return "Person";}
void Person::display() const { std::cout<<"ID: "<<id<<" | Name: "<<name<<" | Phone: "<<phone; }
