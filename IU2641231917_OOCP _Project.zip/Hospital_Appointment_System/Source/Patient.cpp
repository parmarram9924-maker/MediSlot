#include "Patient.h"
#include <iostream>
Patient::Patient():Person(),age(0),gender(""){}
Patient::Patient(int i,const std::string& n,const std::string& p,int a,const std::string& g):Person(i,n,p),age(a),gender(g){}
std::string Patient::role() const{return "Patient";}
void Patient::display() const {Person::display();std::cout<<" | Age: "<<age<<" | Gender: "<<gender;}
int Patient::getAge() const{return age;}
std::string Patient::getGender() const{return gender;}
