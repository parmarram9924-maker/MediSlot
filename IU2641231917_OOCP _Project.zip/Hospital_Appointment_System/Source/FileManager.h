#ifndef FILEMANAGER_H
#define FILEMANAGER_H
#include <string>
#include <vector>
#include "Patient.h"
#include "Doctor.h"
#include "Appointment.h"
class FileManager {
    std::string directory;
public:
    explicit FileManager(const std::string& directory="Data");
    bool savePatients(const std::vector<Patient>& items) const;
    bool loadPatients(std::vector<Patient>& items) const;
    bool saveDoctors(const std::vector<Doctor>& items) const;
    bool loadDoctors(std::vector<Doctor>& items) const;
    bool saveAppointments(const std::vector<Appointment>& items) const;
    bool loadAppointments(std::vector<Appointment>& items) const;
};
#endif
