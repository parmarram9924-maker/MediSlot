#ifndef DOCTOR_H
#define DOCTOR_H
#include "Person.h"
class Doctor : public Person {
    std::string specialization;
public:
    Doctor();
    Doctor(int id,const std::string& name,const std::string& phone,const std::string& specialization);
    std::string role() const override;
    void display() const override;
    std::string getSpecialization() const;
};
#endif
