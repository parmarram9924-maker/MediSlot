UML DIAGRAMS
The .puml files are PlantUML source diagrams. Render them with a PlantUML extension in VS Code or an online PlantUML renderer.
Files: UseCase.puml, ClassDiagram.puml, Sequence1_BookAppointment.puml, Sequence2_SearchRecord.puml.
