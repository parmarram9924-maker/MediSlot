Place screenshots of successful program runs here after building and running the project.
