@echo off
setlocal
cd /d "%~dp0"
if not exist Executable mkdir Executable
where g++ >nul 2>nul
if errorlevel 1 (
  echo ERROR: g++ compiler not found.
  echo Install MinGW-w64 and add its bin folder to PATH, then reopen terminal.
  pause
  exit /b 1
)
g++ -std=c++11 -Wall -Wextra Source\main.cpp Source\Person.cpp Source\Patient.cpp Source\Doctor.cpp Source\Appointment.cpp Source\FileManager.cpp Source\Hospital.cpp -o Executable\HospitalAppointmentSystem.exe
if errorlevel 1 (
  echo BUILD FAILED. Read the compiler errors above.
  pause
  exit /b 1
)
echo.
echo Build successful: Executable\HospitalAppointmentSystem.exe
echo Run it from this project folder so Data files are stored correctly.
pause
