HOSPITAL APPOINTMENT SYSTEM
Project Code: CPP77
Enrollment Number: IU2641231917
Language: C++ (C++17)

FEATURES
- Add, display, search, update and delete patient, doctor and appointment records.
- Book appointments with basic doctor time-conflict checking.
- Appointment summary report.
- Data persistence in Data/patients.txt, Data/doctors.txt and Data/appointments.txt.
- OOP: encapsulation, constructors, destructors, inheritance, virtual functions/runtime polymorphism.
- Dynamic memory demonstration is described in the report; core storage uses std::vector for safe ownership.

BUILD ON WINDOWS (VS Code / MinGW)
1. Install a C++ compiler such as MinGW-w64 and ensure g++ is in PATH.
2. Open this project folder in VS Code.
3. Run build.bat from PowerShell or double-click it.
4. It creates Executable\HospitalAppointmentSystem.exe.
5. Run: .\Executable\HospitalAppointmentSystem.exe
IMPORTANT: Run from the project root so the Data folder is found.

BUILD ON LINUX / macOS
From project root:
g++ -std=c++17 -Wall -Wextra Source/*.cpp -o Executable/HospitalAppointmentSystem
./Executable/HospitalAppointmentSystem

If PowerShell says the executable is not found, first run .\build.bat and check for the "Build successful" message. Confirm the file exists using:
Test-Path .\Executable\HospitalAppointmentSystem.exe

DATA FORMAT
Pipe-delimited plain text. Avoid entering the | character in fields.
Keep the included Data folder beside Source and Executable. This version avoids <filesystem> for compatibility with older MinGW compilers; if you delete Data, recreate it manually.
